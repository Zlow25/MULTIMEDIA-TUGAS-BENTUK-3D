function setup() {
  createCanvas(1000, 500, WEBGL);

  describe(
    'disini saya membuat bentuk kerucut dengan sketsa garis hitamputih'
  );
}

function draw() {
  background(250);

  push();
  translate(-150, 90, 110);
  rotateZ(frameCount * 0.03);
  rotateX(frameCount * 0.02);
  rotateY(frameCount * 0.01);
  cone(80, 110);
  pop();
}
